document.addEventListener("DOMContentLoaded", function() {
  const loginForm = document.getElementById("login-form");
  const bookingForm = document.getElementById("booking-form");
  
  // Check if user is already logged in
  if (localStorage.getItem("admission")) {
    document.getElementById("login-screen").classList.add("hidden");
    document.getElementById("main-content").classList.remove("hidden");
  }
  
  // Handle Login
  loginForm.addEventListener("submit", function(event) {
    event.preventDefault();
    let admission = document.getElementById("admission").value;
    
    // Store admission number in localStorage
    localStorage.setItem("admission", admission);
    
    document.getElementById("login-screen").classList.add("hidden");
    document.getElementById("main-content").classList.remove("hidden");
  });
  
  // Load Games
  const games = [
    { name: "FIFA 23", img: "/IMG_0923.jpeg", video: "https://youtu.be/o3V-GvvzjE4?feature=shared" },
    { name: "FIFA 19", img: "/IMG_0924.jpeg", video: "https://youtu.be/zX0AV6yxyrQ?feature=shared" },
    { name: "Gran Turismo", img: "/IMG_0925.jpeg", video: "https://youtu.be/PaVFn_TBDWs?feature=shared" },
  ];
  
  const gameList = document.getElementById("game-list");
  
  games.forEach((game) => {
    let card = document.createElement("div");
    card.classList.add("game-card");
    card.innerHTML = `
            <img src="${game.img}" alt="${game.name}">
            <h3>${game.name}</h3>
            <button onclick="watchVideo('${game.video}')">Watch Gameplay</button>
        `;
    gameList.appendChild(card);
  });
  
  // Watch Video
  window.watchVideo = function(url) {
    window.open(url, "_blank");
  };
  
  // Booking Form
  bookingForm.addEventListener("submit", function(event) {
    event.preventDefault();
    document.getElementById("confirmation").classList.remove("hidden");
    
    // Redirect to Google Form
    window.location.href = "https://docs.google.com/forms/d/e/1FAIpQLScb19NbNymKGFf3Cn440SdeHwuMCVu9kpIfs4ah9oWrnncMOg/viewform";
  });
});
function watchVideo(url) {
  window.open(url, "_blank");
}